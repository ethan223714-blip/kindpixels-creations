PIXEL ADVENTURE — WINDOWS DOWNLOAD

1. Extract PixelAdventure-Windows.zip.
2. Double-click PixelAdventure.exe to play.

Controls:
Move: A/D or Left/Right Arrow
Jump: Space
Boss skill: X (boss stage only)
Pause: Esc

This build is for 64-bit Windows. No separate Python installation is required.
